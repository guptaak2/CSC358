/**********************************************************************
 * file:  sr_router.c
 * date:  Mon Feb 18 12:50:42 PST 2002
 * Contact: casado@stanford.edu
 *
 * Description:
 *
 * This file contains all the functions that interact directly
 * with the routing table, as well as the main entry method
 * for routing.
 *
 **********************************************************************/

#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include "sr_if.h"
#include "sr_rt.h"
#include "sr_router.h"
#include "sr_protocol.h"
#include "sr_arpcache.h"
#include "sr_utils.h"

/*---------------------------------------------------------------------
 * Method: sr_init(void)
 * Scope:  Global
 *
 * Initialize the routing subsystem
 *
 *---------------------------------------------------------------------*/


void handle_arpreq(struct sr_instance* sr, struct sr_arpreq *request);

void sr_init(struct sr_instance* sr)
{
    /* REQUIRES */
    assert(sr);

    /* Initialize cache and cache cleanup thread */
    sr_arpcache_init(&(sr->cache));

    pthread_attr_init(&(sr->attr));
    pthread_attr_setdetachstate(&(sr->attr), PTHREAD_CREATE_JOINABLE);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_t thread;

    pthread_create(&thread, &(sr->attr), sr_arpcache_timeout, sr);
    
    /* Add initialization code here! */

} /* -- sr_init -- */

/*---------------------------------------------------------------------
 * Method: sr_handlepacket(uint8_t* p,char* interface)
 * Scope:  Global
 *
 * This method is called each time the router receives a packet on the
 * interface.  The packet buffer, the packet length and the receiving
 * interface are passed in as parameters. The packet is complete with
 * ethernet headers.
 *
 * Note: Both the packet buffer and the character's memory are handled
 * by sr_vns_comm.c that means do NOT delete either.  Make a copy of the
 * packet instead if you intend to keep it around beyond the scope of
 * the method call.
 *
 *---------------------------------------------------------------------*/

void sr_handlepacket(struct sr_instance* sr,
        uint8_t * packet/* lent */,
        unsigned int len,
        char* interface/* lent */)
{
  /* REQUIRES */
  assert(sr);
  assert(packet);
  assert(interface);

  printf("*** -> Received packet of length %d \n",len);

 	/* ethernet Interface */
  	struct sr_if *received_interface = (struct sr_if *) sr_get_interface(sr, interface);

  	if (received_interface) {
  		fprintf(stderr,"Packet received on interface: %s\n", received_interface->name);
  	} else {
  		fprintf(stderr, "Invalid interface: %s\n", interface);
  	}

	if (len < (sizeof(sr_ethernet_hdr_t))) {
		fprintf(stderr, "Invalid packet length\n");
		return;
	}

	/* check what kind of packet we got */
	switch (ethertype(packet)) {
		/* if we get an ARP Packet */
		case ethertype_arp:
			fprintf(stderr, "It's an ARP Packet. \n");
			if((sanity_check(len, 0)) != 0){
				fprintf(stderr, "Didn't pass sanity_check\n");
				return;
			} 
			
			/*Get headers for the original packet*/
			sr_arp_hdr_t *recd_arp_header = (sr_arp_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));
			sr_ethernet_hdr_t *recd_ethernet_header = (sr_ethernet_hdr_t *)packet;
			struct sr_if *recd_interface = sr_get_interface(sr, interface);
			
			/*Determine ARP type*/
			if(ntohs(recd_arp_header->ar_op) == arp_op_reply){
				/*ARP OP REPLY*/
				fprintf(stderr, "It's an ARP Reply\n");
				
				/*Cache requests*/
				struct sr_arpreq *cached_req = sr_arpcache_insert(&(sr->cache), recd_arp_header->ar_sha, recd_arp_header->ar_sip);
				
				/*Check to see if there are any cached requests*/
				if(cached_req) {
					/*Send packets that are on arp cache*/
					struct sr_packet *packets_waiting = cached_req->packets;
					while (packets_waiting) {
						
						/*Get the waiting packet*/
						uint8_t *new_packet = packets_waiting->buf;
						
						/*Create the header for packet*/
						sr_ethernet_hdr_t *outgoing_ethernet_header = (sr_ethernet_hdr_t *) new_packet;
						
						/*Update destination and source for packet*/
						memcpy(outgoing_ethernet_header->ether_dhost, recd_arp_header->ar_sha, ETHER_ADDR_LEN);
						memcpy(outgoing_ethernet_header->ether_shost, recd_interface->addr, ETHER_ADDR_LEN);

						/* Send Packet */
						if ((sr_send_packet(sr, new_packet, packets_waiting->len, interface)) == 0) {
							printf("*** -> Sent packet of length %d \n", packets_waiting->len);
						}
						
						/*Now do the next packet*/
						packets_waiting = packets_waiting->next;
					}
					sr_arpreq_destroy(&(sr->cache), cached_req);
				}
				return;

			} else if(ntohs(recd_arp_header->ar_op) == arp_op_request) {
				/* ARP OP REQUEST */
				fprintf(stderr, "It's an ARP Request\n");

				if (recd_interface->ip != recd_arp_header->ar_tip) {
					/*This packet is not for this interface. Nothing more to do.*/
					return;
				}

				/*Prepare the ARP response*/
				uint8_t *arp_response = (uint8_t *) malloc(len);
				memset(arp_response, 0, len * sizeof(uint8_t));

				/* Populate ARP Reply Header */   
				sr_arp_hdr_t *arp_response_header = (sr_arp_hdr_t *)(arp_response + sizeof(sr_ethernet_hdr_t));
				memcpy(arp_response_header, recd_arp_header, sizeof(sr_arp_hdr_t));
				memcpy(arp_response_header->ar_tha, recd_ethernet_header->ether_shost, ETHER_ADDR_LEN);
				memcpy(arp_response_header->ar_sha, recd_interface->addr, ETHER_ADDR_LEN);
				arp_response_header->ar_op = htons(arp_op_reply);
				arp_response_header->ar_tip = recd_arp_header->ar_sip;
				arp_response_header->ar_sip = recd_interface->ip;

				/* Populate Ethernet Reply Header */
				sr_ethernet_hdr_t *arp_eth_response = (sr_ethernet_hdr_t *) arp_response;
				memcpy(arp_eth_response->ether_dhost, recd_ethernet_header->ether_shost, sizeof(uint8_t) * ETHER_ADDR_LEN);
				memcpy(arp_eth_response->ether_shost, recd_interface->addr, sizeof(uint8_t) * ETHER_ADDR_LEN);
				arp_eth_response->ether_type = htons(ethertype_arp);

				/* Send Packet */
				if ((sr_send_packet(sr, arp_response, len, interface)) == 0) {
					printf("*** -> Sent packet of length %d \n",len);
				}

				free(arp_response);
			}
		break; /* END OF ARP CASE */	

		/* If we get an IP Packet */
		case ethertype_ip: 
			fprintf(stderr, "It's an IP Packet.\n");
			
			/*Perform sanity check for length*/
			if((sanity_check(len, 1)) != 0){
				fprintf(stderr, "Didn't pass sanity_check\n");
				return;
			} 

			/*Get the headers for packet*/
			sr_ip_hdr_t *recd_ip_header = (sr_ip_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));
			sr_icmp_t3_hdr_t *recd_icmp_header = (sr_icmp_t3_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));

			/*Validate the checksum for incoming packet*/
			if ((validate_ip_checksum(recd_ip_header, sizeof(sr_ip_hdr_t))) != 0) {
				/* checksum incorrect */
				return;
			} 

			/*Look for a matching interface*/
			struct sr_if *curr_iface = sr->if_list;
    		struct sr_if *dst_iface = NULL;

    		while (curr_iface) {
        		if (recd_ip_header->ip_dst == curr_iface->ip) {				
            		dst_iface = curr_iface;
            		break;
        		}
        		curr_iface = curr_iface->next;
    		}

    		if (dst_iface) {
				/*We found a matching interface*/
    			if (recd_ip_header->ip_p == ip_protocol_icmp) {
					/*ICMP Packet*/
    				if ((sanity_check(len, 2)) == 0){
    					if ((validate_icmp_checksum(recd_icmp_header, len - sizeof(sr_ethernet_hdr_t) - sizeof(sr_ip_hdr_t))) != 0) {
    						/* invalid checksum */
    						return;
    					} 
    				} else {
    					/* icmp sanity check failed */
    					return;
    				}

    				if (recd_icmp_header->icmp_type != 8) {
    					fprintf(stderr, "This is not an ICMP echo request message.\n");
    					return;
    				} else {
    					struct sr_arpentry *mac_addr = sr_arpcache_lookup(&(sr->cache), recd_ip_header->ip_src);
						struct sr_rt *next_hop = LPM(sr, recd_ip_header->ip_src);
	    				struct sr_if *icmp_iface = sr_get_interface(sr, next_hop->interface);
    					if (!mac_addr) {
	    					struct sr_arpreq *arp_req = sr_arpcache_queuereq(&(sr->cache), recd_ip_header->ip_src, packet, len, icmp_iface->name);
							handle_arpreq(sr, arp_req); 
							send_icmp_packet(sr, packet, len, interface, 0x00, 0x00, dst_iface);
							return;
						}
						send_icmp_packet(sr, packet, len, interface, 0x00, 0x00, dst_iface);
						return;
	    			}
    			} else {
    				/* NOT AN ICMP PACKET. TCP/UDP default case */
    				send_icmp_packet(sr, packet, len, interface, 3, 3, dst_iface);
    				return;
    			}
    		} else {
    			/* not for one of our router's interfaces */
    			if (1 >= recd_ip_header->ip_ttl) {
    				/* time to live field expired */
    				send_icmp_packet(sr, packet, len, interface, 11, 0, NULL);
    				return;
    			}

    			struct sr_rt *next_hop = LPM(sr, recd_ip_header->ip_dst);
    			if (!next_hop) {
    				/* could not find next hop ip */
    				send_icmp_packet(sr, packet, len, interface, 3, 0, NULL);
    				return;
    			}
				
				/*Update the time to live*/
    			recd_ip_header->ip_ttl=recd_ip_header->ip_ttl - 1;
    			recd_ip_header->ip_sum = 0;
    			recd_ip_header->ip_sum = cksum(recd_ip_header, sizeof(sr_ip_hdr_t));
				
    			struct sr_arpentry *next_mac = sr_arpcache_lookup(&(sr->cache), next_hop->gw.s_addr);
    			if (!next_mac) {
    				/* could not find next hop mac cache entry */
    				struct sr_arpreq *queued_entry = sr_arpcache_queuereq(&(sr->cache), next_hop->gw.s_addr, packet, len, next_hop->interface);
    				handle_arpreq(sr, queued_entry);
    				return;
    			}

    			/* construct ethernet header */
    			sr_ethernet_hdr_t *outgoing_ethernet_header = (sr_ethernet_hdr_t *) packet;
    			memcpy(outgoing_ethernet_header->ether_shost, sr_get_interface(sr, next_hop->interface)->addr, sizeof(uint8_t) * ETHER_ADDR_LEN);
    			memcpy(outgoing_ethernet_header->ether_dhost, next_mac->mac, sizeof(uint8_t) * ETHER_ADDR_LEN);

    			/*Clean up here*/
				free(next_mac);

				/* Send Packet */
				if ((sr_send_packet(sr, packet, len, sr_get_interface(sr, next_hop->interface)->name)) == 0) {
					printf("*** -> Sent packet of length %d \n",len);
				}

				return;
    		}
    		break;
	} 
} /* end sr_ForwardPacket */


/** 
	Find interface using Longest Prefix Match (LPM) 
	@param sr
		Router Instance
	@param dst_ip
		The IP of the destination we will perform LPM against
	@return The routing table entry that matches
**/
struct sr_rt *LPM(struct sr_instance *sr, uint32_t dst_ip) {
	/*
		Following helper functions from sr_rt
		loop through and find a matching entry
	*/
	
	/*Get the routing table*/
    struct sr_rt *routing_table_entry = sr->routing_table;
    struct sr_rt *longest = NULL;
	
	/*Loop over each entry in the table*/
    while (routing_table_entry) {
        if ((routing_table_entry->dest.s_addr & routing_table_entry->mask.s_addr) == (dst_ip & routing_table_entry->mask.s_addr)) {
            if (!longest || (routing_table_entry->mask.s_addr > longest->mask.s_addr)) {
				/*Found an entry, update longest*/
                longest = routing_table_entry;
            }
        }
		/*Check the next entry*/
        routing_table_entry = routing_table_entry->next;
    }
    return longest;
}
/**
	A helper function to send ICMP packets. 
	@param sr
		The router instance
	@param packet
		The incoming packet that will be used to populate the new packet
	@param icmp_recd
		Length of the received icmp packet
	@param recd_interface
		The interface on which the packet came on 
	@param icmp_type
		The type of the icmp packet we will send
	@param code
		The code for the new packet
	@param dst_interface
		The interface we want to send the packet to	
**/
void send_icmp_packet(struct sr_instance *sr, uint8_t *packet, unsigned int icmp_recd, char *recd_interface, 
						uint8_t icmp_type, uint8_t code, struct sr_if *dst_interface){
	
	/**Create the headers for the original packet*/
	sr_ethernet_hdr_t *recd_ethernet_header = (sr_ethernet_hdr_t *) (packet);
	sr_ip_hdr_t *recd_ip_hdr = (sr_ip_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t));
	/* sr_icmp_t3_hdr_t *recd_icmp_header = (sr_icmp_t3_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t)); */
	sr_icmp_hdr_t *recd_icmp_not3_header = (sr_icmp_hdr_t *) (packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
	
	/*Calculate icmp len*/
	int icmp_len = sizeof(sr_icmp_t3_hdr_t) + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t);
	int icmp_send;
	/*Check to see if its icmp echo*/
	if(icmp_type != 0x00){
		/*Not ECHO*/
		icmp_send = icmp_len;
	}else{
		/*ECHO*/
		
		/*Packet will be of the same size as the one received*/
		icmp_send = icmp_recd;
	}
	
	/*Create a new icmp packet*/
	uint8_t *outgoing_packet = (uint8_t *) malloc(icmp_send);
	memset(outgoing_packet, 0, sizeof(uint8_t) * icmp_send);
	
	/*Create the headers for the new packet*/
	sr_ethernet_hdr_t *outgoing_ethernet_header = (sr_ethernet_hdr_t *) (outgoing_packet);
	sr_ip_hdr_t *outgoing_ip_header = (sr_ip_hdr_t *) (outgoing_packet + sizeof(sr_ethernet_hdr_t));
	sr_icmp_t3_hdr_t *outgoing_icmp_header = (sr_icmp_t3_hdr_t *) (outgoing_packet + sizeof(sr_ip_hdr_t) + sizeof(sr_ethernet_hdr_t));
	
	/*Where to send the packet*/
	struct sr_if *outgoing_interface = sr_get_interface(sr, recd_interface);
	
	
	
	/*Populate ICMP header*/
	if(icmp_type != 0x00){
		/**Not Echo**/
		
		/**Populate icmp with incoming IP header**/
		memcpy(outgoing_icmp_header->data, recd_ip_hdr, ICMP_DATA_SIZE);
		outgoing_icmp_header->icmp_type = icmp_type;
		outgoing_icmp_header->icmp_code = code;
		
		/**Calculate checksum**/
		outgoing_icmp_header->icmp_sum = 0;
		outgoing_icmp_header->icmp_sum = cksum(outgoing_icmp_header, sizeof(sr_icmp_t3_hdr_t));
	}else{
		/**Echo**/
		/**Populate icmp with incoming ICMP header**/
		memcpy(outgoing_icmp_header, recd_icmp_not3_header, icmp_send - sizeof(sr_ethernet_hdr_t) - sizeof(sr_ip_hdr_t));
		outgoing_icmp_header->icmp_type = icmp_type;
		outgoing_icmp_header->icmp_code = code;
		
		/**Calculate checksum**/
		outgoing_icmp_header->icmp_sum = 0;
		outgoing_icmp_header->icmp_sum = cksum(outgoing_icmp_header, icmp_send - sizeof(sr_ethernet_hdr_t) - sizeof(sr_ip_hdr_t));
	}
	
	
	/**Populate IP Header**/
	memcpy(outgoing_ip_header, recd_ip_hdr, sizeof(sr_ip_hdr_t));
	outgoing_ip_header->ip_p = ip_protocol_icmp;/**Always ICMP since sr can only send ICMP packets**/
	
	/**Destination is the source the original packet was sent from**/
	outgoing_ip_header->ip_dst = recd_ip_hdr->ip_src;
	outgoing_ip_header->ip_len = htons(icmp_send - sizeof(sr_ethernet_hdr_t));
	
	if(dst_interface){
		outgoing_ip_header->ip_src = dst_interface->ip;
	}else{
		outgoing_ip_header->ip_src = outgoing_interface->ip;
	}
	
	/**Set TTL to default initial TTL defined in sr_router.h**/
	outgoing_ip_header->ip_ttl = INIT_TTL;
	
	/**Since TTL was changed, re-calculate checksum**/
	outgoing_ip_header->ip_sum = 0;
	outgoing_ip_header->ip_sum = cksum(outgoing_ip_header, sizeof(sr_ip_hdr_t));
	
	
	/**Populate Ethernet Header**/
	/**Source address will be interface**/
	memcpy(outgoing_ethernet_header->ether_shost, outgoing_interface->addr, sizeof(uint8_t)*ETHER_ADDR_LEN);
	memcpy(outgoing_ethernet_header->ether_dhost, recd_ethernet_header->ether_shost, sizeof(uint8_t)*ETHER_ADDR_LEN);
	outgoing_ethernet_header->ether_type = htons(ethertype_ip);
	
	/**Send Packet Now**/
	if((sr_send_packet(sr, outgoing_packet, icmp_send, recd_interface)) == 0){
		/**Successfully sent the packet**/
		printf("*** -> Sent packet of length %d\n", icmp_send);
	}
	
	/*Cleanup here*/
	free(outgoing_packet);
	return;
}